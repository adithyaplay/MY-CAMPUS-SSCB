import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => ThemeProvider(),
      child: CollegeCampusApp(),
    ),
  );
}

class ThemeProvider with ChangeNotifier {
  Color _primaryColor = Colors.blue;
  Color _secondaryColor = Colors.green;
  int _colorIndex = 0;

  Color get primaryColor => _primaryColor;
  Color get secondaryColor => _secondaryColor;

  final List<Color> _primaryColors = [
    Colors.blue,
    Colors.purple,
    Colors.teal,
    Colors.orange,
    Colors.pink,
    Colors.indigo,
    Colors.deepOrange,
  ];

  final List<Color> _secondaryColors = [
    Colors.green,
    Colors.indigo,
    Colors.cyan,
    Colors.amber,
    Colors.purpleAccent,
    Colors.blueAccent,
    Colors.deepPurple,
  ];

  void changeTheme() {
    _colorIndex = (_colorIndex + 1) % _primaryColors.length;
    _primaryColor = _primaryColors[_colorIndex];
    _secondaryColor = _secondaryColors[_colorIndex];
    notifyListeners();
  }

  LinearGradient get gradient => LinearGradient(
        colors: [primaryColor, secondaryColor],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  LinearGradient get lightGradient => LinearGradient(
        colors: [primaryColor.withOpacity(0.1), secondaryColor.withOpacity(0.1)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
}

class CollegeCampusApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SSCB CAMPUS',
      theme: ThemeData(
        primarySwatch: _createMaterialColor(themeProvider.primaryColor),
        visualDensity: VisualDensity.adaptivePlatformDensity,
        scaffoldBackgroundColor: Colors.grey[50],
      ),
      home: SplashScreen(),
      routes: {
        '/home': (context) => HomeScreen(),
        '/events': (context) => EventsScreen(),
        '/gallery': (context) => GalleryScreen(),
        '/map': (context) => MapScreen(),
        '/complaint': (context) => ComplaintScreen(),
        '/faculty': (context) => FacultyScreen(),
        '/notifications': (context) => NotificationsScreen(),
      },
    );
  }

  MaterialColor _createMaterialColor(Color color) {
    List<double> strengths = <double>[.05];
    Map<int, Color> swatch = {};
    final int r = color.red, g = color.green, b = color.blue;

    for (int i = 1; i < 10; i++) {
      strengths.add(0.1 * i);
    }

    for (var strength in strengths) {
      final double ds = 0.5 - strength;
      swatch[(strength * 1000).round()] = Color.fromRGBO(
        r + ((ds < 0 ? r : (255 - r)) * ds).round(),
        g + ((ds < 0 ? g : (255 - g)) * ds).round(),
        b + ((ds < 0 ? b : (255 - b)) * ds).round(),
        1,
      );
    }

    return MaterialColor(color.value, swatch);
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacementNamed(context, '/home');
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: themeProvider.gradient,
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.school,
                  size: 60,
                  color: themeProvider.primaryColor,
                ),
              ),
              SizedBox(height: 30),
              Text(
                'SSCB MY CAMPUS',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Colors.white)),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String marqueeText = 'WELCOME TO MY-CAMPUS APP | MY CAMPUS BY ADITHYAPLAY | ದಿನಾಂಕ 5-11-2025 ರಿಂದ ಕಾಲೇಜಿನಲ್ಲಿ ಪೋಷಕರ ಸಭೆ ಇರುತ್ತದೆ.';
  late AnimationController _controller;
  late Animation<Offset> _animation;
  
  final PageController _pageController = PageController();
  int _currentIndex = 0;
  Timer? _carouselTimer;
  
  final List<String> carouselImages = [
    'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600',
    'https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?w=600',
    'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600',
  ];

  @override
  void initState() {
    super.initState();
    
    _controller = AnimationController(
      duration: Duration(seconds: 15),
      vsync: this,
    )..repeat();
    
    _animation = Tween<Offset>(
      begin: Offset(1.0, 0.0),
      end: Offset(-1.0, 0.0),
    ).animate(_controller);

    _startAutoScroll();
  }

  void _startAutoScroll() {
    _carouselTimer = Timer.periodic(Duration(seconds: 3), (timer) {
      if (_pageController.hasClients) {
        final nextPage = (_currentIndex + 1) % carouselImages.length;
        _pageController.animateToPage(
          nextPage,
          duration: Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _pageController.dispose();
    _carouselTimer?.cancel();
    super.dispose();
  }

  Future<void> _launchUrl(String url) async {
    try {
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(Uri.parse(url));
      }
    } catch (e) {
      print('Could not launch $url: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open $url')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      key: _scaffoldKey,
      drawer: AppDrawer(),
      appBar: AppBar(
        title: Text('SSCB MY CAMPUS', style: GoogleFonts.poppins()),
        backgroundColor: themeProvider.primaryColor,
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {
              Navigator.pushNamed(context, '/notifications');
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: themeProvider.lightGradient,
        ),
        child: Column(
          children: [
            // Marquee Text
            Container(
              height: 40,
              decoration: BoxDecoration(
                gradient: themeProvider.gradient,
              ),
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Icon(Icons.announcement, color: Colors.white, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: SlideTransition(
                      position: _animation,
                      child: Text(
                        marqueeText,
                        style: GoogleFonts.poppins(
                          color: Colors.white, 
                          fontWeight: FontWeight.bold
                        ),
                        overflow: TextOverflow.visible,
                        softWrap: false,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Image Carousel
            Container(
              height: 180,
              margin: EdgeInsets.all(16),
              child: Column(
                children: [
                  Expanded(
                    child: PageView.builder(
                      controller: _pageController,
                      onPageChanged: (index) {
                        setState(() {
                          _currentIndex = index;
                        });
                      },
                      itemCount: carouselImages.length,
                      itemBuilder: (context, index) {
                        return Container(
                          margin: EdgeInsets.symmetric(horizontal: 8.0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 6,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12.0),
                            child: Image.network(
                              carouselImages[index],
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: Colors.grey[300],
                                  child: Icon(Icons.error, size: 50),
                                );
                              },
                              loadingBuilder: (context, child, loadingProgress) {
                                if (loadingProgress == null) return child;
                                return Container(
                                  color: Colors.grey[200],
                                  child: Center(
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 10),
                  // Indicator dots
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(carouselImages.length, (index) {
                      return Container(
                        width: 8.0,
                        height: 8.0,
                        margin: EdgeInsets.symmetric(horizontal: 4.0),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _currentIndex == index 
                              ? themeProvider.primaryColor 
                              : Colors.grey[400],
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ),
            
            // Main Content Grid
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: GridView.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 0.9,
                  children: [
                    _buildFeatureCard(
                      title: 'UPCOMING EVENTS',
                      icon: Icons.event,
                      color: Colors.red,
                      onTap: () => Navigator.pushNamed(context, '/events'),
                    ),
                    _buildFeatureCard(
                      title: 'GALLERY',
                      icon: Icons.photo_library,
                      color: Colors.purple,
                      onTap: () => Navigator.pushNamed(context, '/gallery'),
                    ),
                    _buildFeatureCard(
                      title: 'CAMPUS MAP',
                      icon: Icons.map,
                      color: Colors.green,
                      onTap: () => Navigator.pushNamed(context, '/map'),
                    ),
                    _buildFeatureCard(
                      title: 'COMPLAINT',
                      icon: Icons.report_problem,
                      color: Colors.orange,
                      onTap: () => Navigator.pushNamed(context, '/complaint'),
                    ),
                    _buildFeatureCard(
                      title: 'FACULTY',
                      icon: Icons.people,
                      color: Colors.blue,
                      onTap: () => Navigator.pushNamed(context, '/faculty'),
                    ),
                    _buildFeatureCard(
                      title: 'SHARE APP',
                      icon: Icons.share,
                      color: Colors.teal,
                      onTap: () => _showShareDialog(context),
                    ),
                  ],
                ),
              ),
            ),
            
            // Contact Bar
            Container(
              height: 50,
              decoration: BoxDecoration(
                gradient: themeProvider.gradient,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  IconButton(
                    icon: Icon(Icons.phone, color: Colors.white),
                    onPressed: () => _launchUrl('tel:+917411465861'),
                  ),
                  IconButton(
                    icon: Icon(Icons.email, color: Colors.white),
                    onPressed: () => _launchUrl('mailto:adithyaplayofficial@gmail.com'),
                  ),
                  IconButton(
                    icon: Icon(Icons.web, color: Colors.white),
                    onPressed: () => _launchUrl('https://www.adithyaplay.app'),
                  ),
                  IconButton(
                    icon: Icon(Icons.location_on, color: Colors.white),
                    onPressed: () => _launchUrl('https://maps.google.com/?q=SSCBA+PK+Campus'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeatureCard({required String title, required IconData icon, required Color color, required VoidCallback onTap}) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: color),
            SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showShareDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Share App', style: GoogleFonts.poppins()),
        content: Text('Share MY Campus app with your friends!', style: GoogleFonts.poppins()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: GoogleFonts.poppins()),
          ),
        ],
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: themeProvider.gradient,
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.school, color: themeProvider.primaryColor, size: 30),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'SSCB MY CAMPUS',
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'BY ADITHYAPLAY ',
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            
            // Theme Changer Button
            ListTile(
              leading: Icon(Icons.color_lens, color: Colors.white),
              title: Text('Change Theme', style: GoogleFonts.poppins(color: Colors.white)),
              onTap: () {
                themeProvider.changeTheme();
                Navigator.pop(context);
              },
            ),
            
            ListTile(
              leading: Icon(Icons.info, color: Colors.white),
              title: Text('About App', style: GoogleFonts.poppins(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('About App', style: GoogleFonts.poppins()),
                    content: Text('SSCB MY CAMPUS app helps students and teachers stay connected with campus activities, events, and resources.', style: GoogleFonts.poppins()),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('OK', style: GoogleFonts.poppins()),
                      ),
                    ],
                  ),
                );
              },
            ),
            
            ListTile(
              leading: Icon(Icons.person, color: Colors.white),
              title: Text('About Developer', style: GoogleFonts.poppins(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('About Developer', style: GoogleFonts.poppins()),
                    content: Text('Developed by ADITHYAPLAY with passion for creating innovative solutions for education.', style: GoogleFonts.poppins()),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('OK', style: GoogleFonts.poppins()),
                      ),
                    ],
                  ),
                );
              },
            ),
            
            ListTile(
              leading: Icon(Icons.contact_mail, color: Colors.white),
              title: Text('Contact Details', style: GoogleFonts.poppins(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Contact Details', style: GoogleFonts.poppins()),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('📧 Email: adithyaplayofficial@gmail.com', style: GoogleFonts.poppins()),
                        SizedBox(height: 8),
                        Text('📞 Phone: +91 7411465861', style: GoogleFonts.poppins()),
                        SizedBox(height: 8),
                        Text('📍 Address: RG SPFT-TECH PLTD AMPAR,KUNDAPURA.KARNATAKA', style: GoogleFonts.poppins()),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('OK', style: GoogleFonts.poppins()),
                      ),
                    ],
                  ),
                );
              },
            ),
            
            Divider(color: Colors.white54),
            
            ListTile(
              leading: Icon(Icons.exit_to_app, color: Colors.white),
              title: Text('Close Menu', style: GoogleFonts.poppins(color: Colors.white)),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
}

// Screen Classes with Proper Content
class EventsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Upcoming Events', style: GoogleFonts.poppins()),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildEventCard('Annual Sports Day', 'December 15, 2023', 'Main Ground'),
            _buildEventCard('Science Exhibition', 'December 20, 2023', 'Science Block'),
            _buildEventCard('Cultural Festival', 'January 5, 2024', 'Auditorium'),
            _buildEventCard('Career Counseling', 'January 12, 2024', 'Conference Hall'),
          ],
        ),
      ),
    );
  }

  Widget _buildEventCard(String title, String date, String venue) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      child: ListTile(
        leading: Icon(Icons.event, color: Colors.blue),
        title: Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date: $date'),
            Text('Venue: $venue'),
          ],
        ),
        trailing: Icon(Icons.arrow_forward_ios, size: 16),
      ),
    );
  }
}

class GalleryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Photo Gallery', style: GoogleFonts.poppins()),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(6, (index) {
          return Container(
            margin: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: NetworkImage('https://picsum.photos/200/300?random=$index'),
                fit: BoxFit.cover,
              ),
            ),
          );
        }),
      ),
    );
  }
}

class MapScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Campus Map', style: GoogleFonts.poppins()),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.map, size: 100, color: Colors.grey),
            SizedBox(height: 20),
            Text('Campus Map', style: GoogleFonts.poppins(fontSize: 24)),
            SizedBox(height: 10),
            Text('Interactive campus map will be displayed here', 
                 style: GoogleFonts.poppins(), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class ComplaintScreen extends StatefulWidget {
  @override
  _ComplaintScreenState createState() => _ComplaintScreenState();
}

class _ComplaintScreenState extends State<ComplaintScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  
  String? _selectedDepartment;
  String? _selectedComplaintType;
  
  final List<String> _departments = ['BCOM', 'BCA', 'BA', 'BBA'];
  final List<String> _complaintTypes = [
    'RAGGING', 
    'DRUGS', 
    'HARASSMENT', 
    'OTHER PROBLEM'
  ];
  
  bool _isSubmitting = false;
  
  @override
  void dispose() {
    _nameController.dispose();
    _noteController.dispose();
    super.dispose();
  }
  
  void _submitComplaint() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isSubmitting = true;
      });
      
      // Simulate API call
      Future.delayed(Duration(seconds: 2), () {
        setState(() {
          _isSubmitting = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Complaint submitted successfully!'),
            backgroundColor: Colors.green,
          )
        );
        
        // Clear form
        _formKey.currentState!.reset();
        _nameController.clear();
        _noteController.clear();
        setState(() {
          _selectedDepartment = null;
          _selectedComplaintType = null;
        });
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Complaint', style: GoogleFonts.poppins()),
        backgroundColor: themeProvider.primaryColor,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: themeProvider.lightGradient,
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Center(
                  child: Column(
                    children: [
                      Icon(Icons.report_problem, size: 60, color: themeProvider.primaryColor),
                      SizedBox(height: 10),
                      Text(
                        'Submit Your Complaint',
                        style: GoogleFonts.poppins(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800],
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'ನಿಮ್ಮ ಗುರುತು ಸುರಕ್ಷಿತವಾಗಿರುತ್ತಗೆ',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                
                SizedBox(height: 30),
                
                // Name Field (Optional)
                Text(
                  'Name (Optional)',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[700],
                  ),
                ),
                SizedBox(height: 8),
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    hintText: 'Enter your name if your wish',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                ),
                
                SizedBox(height: 20),
                
                // Department Selection
                Text(
                  'Class/Department *',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[700],
                  ),
                ),
                SizedBox(height: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: DropdownButtonFormField<String>(
                    value: _selectedDepartment,
                    items: _departments.map((dept) {
                      return DropdownMenuItem<String>(
                        value: dept,
                        child: Text(dept, style: GoogleFonts.poppins()),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedDepartment = value;
                      });
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                    ),
                    validator: (value) {
                      if (value == null) {
                        return 'Please select your department';
                      }
                      return null;
                    },
                    isExpanded: true,
                    hint: Text('Select your department', style: GoogleFonts.poppins()),
                    icon: Icon(Icons.arrow_drop_down),
                  ),
                ),
                
                SizedBox(height: 20),
                
                // Complaint Type Selection
                Text(
                  'Complaint Type *',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[700],
                  ),
                ),
                SizedBox(height: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: DropdownButtonFormField<String>(
                    value: _selectedComplaintType,
                    items: _complaintTypes.map((type) {
                      return DropdownMenuItem<String>(
                        value: type,
                        child: Text(type, style: GoogleFonts.poppins()),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedComplaintType = value;
                      });
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                    ),
                    validator: (value) {
                      if (value == null) {
                        return 'Please select complaint type';
                      }
                      return null;
                    },
                    isExpanded: true,
                    hint: Text('Select complaint type', style: GoogleFonts.poppins()),
                    icon: Icon(Icons.arrow_drop_down),
                  ),
                ),
                
                SizedBox(height: 20),
                
                // Note Field
                Text(
                  'Additional Details *',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[700],
                  ),
                ),
                SizedBox(height: 8),
                TextFormField(
                  controller: _noteController,
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: 'Please provide details of your complaint...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    alignLabelWithHint: true,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please provide details of your complaint';
                    }
                    return null;
                  },
                ),
                
                SizedBox(height: 30),
                
                // Submit Button
                SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: _isSubmitting ? null : _submitComplaint,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: themeProvider.primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 3,
                    ),
                    child: _isSubmitting
                        ? SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            'Submit Complaint',
                            style: GoogleFonts.poppins(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ),
                
                SizedBox(height: 20),
                
                // Info Note
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.blue.shade100),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: Colors.blue.shade700),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'All complaints are treated with strict confidentiality. Emergency issues are addressed within 24 hours.',
                          style: GoogleFonts.poppins(
                            color: Colors.blue.shade800,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class FacultyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Faculty Directory', style: GoogleFonts.poppins()),
      ),
      body: ListView(
        children: [
          _buildFacultyCard('Dr.CHANDRAVATHI', 'PRINCIPAL ', 'PhD in KANNADA '),
          _buildFacultyCard('SANDEEP.K', 'Accountency', 'MSc in Mathematics'),
          _buildFacultyCard('Dr. Usman Malik', 'Physics', 'PhD in Physics'),
          _buildFacultyCard('Ms. Fatima Noor', 'English', 'MA in English Literature'),
        ],
      ),
    );
  }

  Widget _buildFacultyCard(String name, String department, String qualification) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        leading: CircleAvatar(child: Icon(Icons.person)),
        title: Text(name, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(department),
            Text(qualification, style: TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class NotificationsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications', style: GoogleFonts.poppins()),
      ),
      body: Center(
        child: Text('No new notifications', style: GoogleFonts.poppins(fontSize: 18)),
      ),
    );
  }
}